#ifndef INIT_H
#define INIT_H

#include <stdbool.h>
#include <avr/io.h>
#include "PulseGenerator.h"
#include "LCD_Driver.h"

void INIT();
#endif